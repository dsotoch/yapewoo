=== YAPE for Virutec===

Contributors: virutec-DiegoSoto
Plugin Name: Pagos Yape Perú
Plugin URI: https://viru-tec.com
Tags: pagos, moviles, peru, yape, yape peru
Author URI: https://regialusit.viru-tec.com
Author: Diego Soto
Requires at least: 5.5
Tested up to: 5.7
Requires PHP: 5.4
Stable tag: 1.1
Version: 1.4
License: GPLv2

Es un Plugin que permite agregar YAPE como forma de pago en tu tienda WooCommerce, YAPE es un medio de pago peruano.

== Description ==

El plugin "Pagos Yape Perú" permite agregar YAPE como forma de pago a su tiendas WooCommerce. YAPE es un medio de pago peruano, por lo que el plugin es para Perú, YAPE permite pagos con su telefono Smartphone.

== Installation ==

1. Carga el plugin dentro de la carpeta `/wp-content/plugins/` o instala desde la lista de plugins
2. Activa el plugin desde la opcion 'Plugins' en el menu de WordPress
3. Entra en la nueva opción llamada "YAPE" en el menú de WooCommerce
4. Dentro podrás agregar el códgio QR de tu comercio, así tus clientes podrán pagarte desde su móvil.

== Changelog ==

= 1.2=
* Primera versión del plugin



= ¿Como uso el QR de mi comercio? =
Solo debes subir la imagen de tu QR y guardar.
= ¿Puedo cambiar mi QR? =
Si, si por alguna razón necesitas cambiar el QR, puedes subir el nuevo reemplazando el anterior.